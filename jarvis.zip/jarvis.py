import pyttsx3
import time
import datetime
import wikipedia
import webbrowser
import os
import json
import random
import smtplib
import requests
import pyjokes
import math
import playsound
import phonenumbers
import pyautogui
import psutil
import textblob
import wolframalpha
import pywhatkit
from pywhatkit import search
from pywikihow import search_wikihow
from psutil import sensors_battery
import speech_recognition as s
from requests import get
from pyautogui import click
from keyboard import press
from keyboard import write
from time import sleep
from time import strftime
from playsound import playsound
from plyer import notification
from phonenumbers import timezone,geocoder,carrier

engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty("voice",voices[0].id)
engine.setProperty("rate",150)
engine.setProperty("rate",150)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()
def print_speak(audio):
    print(audio)
    engine.say(audio)
    engine.runAndWait()
def speak_print(audio):
    engine.say(audio)
    print(audio)
    engine.runAndWait()
def soory():
        print("Say that again please...")
        speak("Sorry but I can't hear you please tell again")
def takecommand():
    sr = s.Recognizer()
    with s.Microphone() as source:
        sr.adjust_for_ambient_noise(source)
        print("Please say something...")
        sr.pause_threshold = 0.8
        try :
            audio = sr.listen(source)
            print("Recognizing now...")
            query = sr.recognize_google(audio,language="en-in")
            print("You have said  :  ",query)
            
        except Exception as e:
            soory()
            return None
        return query
def ques(question):
    client = wolframalpha.Client('JPP653-GLJUU377UV')
    try:
            query = question
            if "exit" in query or "close" in query:
                exit
            else:
                res = client.query(query)
                output = next(res.results).text
                print(output)
                speak(output)
    except:
            print_speak("No result")
def takespeak_or_print():
    sr = s.Recognizer()
    with s.Microphone() as source:
        sr.adjust_for_ambient_noise(source)
        print("What should I do only print responce or both speak and print responce...")
        speak("What should I do only print responce or both speak and print responce")
        try :
            audio = sr.listen(source)
            print("Recognizing Type...")
            query = sr.recognize_google(audio)
            print("Type is  :  ",query)
            
        except Exception as e:
            soory()
            return None
        return query
def wish():
    hour = int(datetime.datetime.now().hour)
    tim=strftime("%H:%M %p")
    que = "At " + str(tim)
    print_speak(que)
    sleep(0.5)
    print_speak("Jarvis activated")
    if hour>=0 and hour<12:
        print_speak("Good morning")
    elif hour>=12 and hour < 18:
        print_speak("Good afternoon")
    else:
        print_speak("Good evening")
    speak("Please tell me how may I help you")
def take():
    sr = s.Recognizer()
    with s.Microphone() as source:
        sr.adjust_for_ambient_noise(source)
        print("Please say what you want to send...")
        try :
            audio = sr.listen(source)
            print("Recognizing your message...")
            query = sr.recognize_google(audio)
            print("your message is  :  ",query)
            
        except Exception as e:
            soory()
            return None
        return query
def takequestion():
    sr = s.Recognizer()
    with s.Microphone() as source:
        sr.adjust_for_ambient_noise(source)
        print("Please ask question...")
        try :
            audio = sr.listen(source)
            print("Recognizing your question...")
            query = sr.recognize_google(audio)
            print("Your question is  :  ",query)
            return query
        except Exception as e:
            soory()
            return None   
def wakeup_or_shutdown():
    sr = s.Recognizer()
    with s.Microphone() as source:
        sr.adjust_for_ambient_noise(source)
        print("Say command...")
        try :
            audio = sr.listen(source)
            print("Recognizing command...")
            query = sr.recognize_google(audio)           
        except Exception as e:
            return None
        return query
def weather(user_input):
    weather_data = requests.get(
        f"https://api.openweathermap.org/data/2.5/weather?q={user_input}&units=imperial&APPID=30d4741c779ba94c470ca1f63045390a")
    if weather_data.json()['cod'] == '404':
        speak("WARNING","No City Found")
        print("City not found")
    else:
        weather = weather_data.json()['weather'][0]['main']
        temp = round(weather_data.json()['main']['temp'])
        temp = int(temp)
        tempe = ((temp-32)*5/9)
        tempe = round(tempe)
        temperature = str(tempe) , " degree celcius"
        weather = "weather is "+weather
        print(str(tempe),"°C ")
        print(weather)
        speak(temperature)
        speak(weather)
        notification.notify(
                        title = "  Weather  ",
                        message = f"{tempe}\n{weather}",
                        timeout = 10)
        playsound("D:\\python\\jarvis\\notification.mp3")
def citytake():
    sr = s.Recognizer()
    with s.Microphone() as source:
        sr.adjust_for_ambient_noise(source)
        speak_print("which state weather you want to check...")        
        try :
            audio = sr.listen(source)
            print("Recognizing city name..")
            query = sr.recognize_google(audio)
            print("city name is  :  ",query)
        except Exception as e:
            soory()
            return None
        return query
def news():
    try:
        api_dict = {"business" : "https://newsapi.org/v2/top-headlines?country=in&category=business&apiKey=2ad49da554d4483fb3bb2cd6e9de740a",
                "entertainment" : "https://newsapi.org/v2/top-headlines?country=in&category=entertainment&apiKey=2ad49da554d4483fb3bb2cd6e9de740a",
                "health" : "https://newsapi.org/v2/top-headlines?country=in&category=health&apiKey=2ad49da554d4483fb3bb2cd6e9de740a",
                "science" :"https://newsapi.org/v2/top-headlines?country=in&category=science&apiKey=2ad49da554d4483fb3bb2cd6e9de740a",
                "sports" :"https://newsapi.org/v2/top-headlines?country=in&category=sports&apiKey=2ad49da554d4483fb3bb2cd6e9de740a",
                "technology" :"https://newsapi.org/v2/top-headlines?country=in&category=technology&apiKey=2ad49da554d4483fb3bb2cd6e9de740a"
        }
        content = None
        url = None
        print_speak("Which field news do you want, [business] , [health] , [technology], [sports] , [entertainment] , [science]")
        field = input("Type field news that you want: ")
        for key ,value in api_dict.items():
            if key.lower() in field.lower():
                url = value
                print(url)
                print("url was found")
                break
            else:
                url = True
        if url is True:
            print("url not found")
        news = requests.get(url).text
        news = json.loads(news)
        speak("Here is the first news.")
        arts = news["articles"]
        for articles in arts :
            article = articles["title"]
            print_speak(article)
            news_url = articles["url"]
            print(f"for more info visit: {news_url}")

            a = input("[press 1 to more news] and [press 2 to stop]")
            if str(a) == "1":
                pass
            elif str(a) == "2":
                break
        speak("thats all")
    except:
        pass
def searchphonedetail(num):
    phone = phonenumbers.parse('+91'+num)
    car = str(carrier.name_for_number(phone,"en"))
    reg = str(geocoder.description_for_number(phone, "en"))
    car = str(car)
    phonenumber = str("+91 "+str(num))
    print_speak(f"Your phone number is :  {phonenumber}")
    print_speak(f"Your SIM company is : {car}")
    print_speak(f"Lacation of your Phone number :  {reg}")
def listToString(s):
    str1 = " "
    return (str1.join(s))
def executation(): 
    wish()
    print("######################################################################################################")
    while 1 :
        query = takecommand()
        query = str(query)
        query = query.lower()
        if "in wikipedia" in query:
            speak_print("Searching Wikipedia please wait...")
            query = query.replace("in wikipedia","")
            results = wikipedia.summary(query,sentences = 2)
            print_speak(f"According to wikipedia {results}")
        elif "on wikipedia" in query:
            speak_print("Searching Wikipedia please wait...")
            query = query.replace("on wikipedia","")
            results = wikipedia.summary(query,sentences = 2) 
            print_speak(f"According to wikipedia {results}")
        elif((("shutdown" in query) or ("shut down" in query))\
              or (("switch off" in query) or ("switchoff" in query))\
                or(("goodbye" in query) or ("good bye" in query))):
            print_speak("Shutting down thanks to use me Have a good day")
            print("######################################################################################################")
            quit()
        elif "how are you"in query or "how r u"in query:
            print_speak("I am fine sir  and you ?")
        elif "thanks"in query:
            print_speak("It's my pleasure sir")
        elif "hello"in query and "jarvis" in query:
            print_speak("Hello sir , Todey how can I help you")
        elif ("fine" in query)or("i am fine" in query):
            print_speak("o! It's great")
            speak("How can i help you sir")
        elif "save" in query and "as" in query:
            b = query.split()
            b[0:4]=""
            name = listToString(b)
            pyautogui.hotkey('ctrl', 's')
            sleep(2)
            write(name)
            sleep(1)
            press("enter")
        elif ("open youtube and search for" in query):
            speak("Opening youtube")
            query = query.replace("open youtube and search for","")
            query = query.replace(" ","+")
            url = "https://www.youtube.com/results?search_query="+query
            webbrowser.open(url)              
        elif ("open youtube" in query) or ("open my youtube" in query):
            speak("Opening youtube")
            webbrowser.open("youtube.com")
        elif ("open wikipedia" in query) or ("open my wikipedia" in query):
            speak("Opening wikipedia")
            webbrowser.open("https://www.wikipedia.org/")
        elif "time now" in query:
            time = datetime.datetime.now().strftime("%H:%M")
            tme = "Current Time is  "+str(time)
            print(tme)
            speak(tme)
        elif ("open chrome" in query) or ("open my chrome" in query):
            speak("Opening chrome")
            os.system(f"start chrome")
        elif ("open edge" in query) or ("open my edge" in query) or ("open microsoft edge" in query):
            speak("Opening edge")
            os.system(f"start microsoftedge")
        elif ("open ms word" in query) or ("open microsoft word" in query):
            speak("Opening Microsoft word")
            os.system(f"start winword")             
        elif ("open power point" in query) or ("open powerpoint" in query):
            speak("Opening Microsoft power point")
            os.system(f"start powerpnt")               
        elif "delete " in query and "selected " in query :
            print_speak("Ok sir , I will delete it")
            pyautogui.hotkey('shift', 'delete')
            sleep(0.5)
            press("enter")
        elif ("open outlook" in query) or ("open mail" in query):
            speak("Opening outlook")
            os.system(f"start outlook")               
        elif ("open onenote" in query) or ("open one note" in query) :
            speak("Opening OneNote")
            os.system(f"start onenote")  
        elif ("open ms excel" in query) or ("open excel" in query) or ("open microsoft excel" in query):
            speak("Opening Microsoft Excel")
            os.system(f"start excel")  
        elif "open " in query and((".com"in query) or (".in" in query) or (".org" in query) or (".co.in" in query)):
            query = query.replace("open ","")
            query = query.replace(" ","")
            webbrowser.open(f"https://www.{query}")
        elif "notepad" in query:
            os.system(f"start notepad")
        elif "cmd" in query or "terminal" in query:
            os.system(f"start cmd")
        elif "open " in query:
            query = query.replace("open ", "")
            query = query.replace(" app", "")
            pyautogui.hotkey("win","s")
            sleep(1)
            write(query)
            sleep(2)
            press("enter")
        elif (("joke" in query)):
            try:
                joke = pyjokes.get_joke()
                print(joke + "\n😂😁🤣😉😂😁🤣😉😂😁🤣😉\n😂😁🤣😉😂😁🤣😉😂😁🤣😉\n😂😁🤣😉😂😁🤣😉😂😁🤣😉")
                speak(joke)
                playsound("D:\\python\\jarvis\\laugh.mp3")
            except Exception as e:
                print_speak("Sorry I cannot able to do this")
        elif ("ip address" in query):
            try:
                print_speak("Searching for your IP Address, Please wait...")
                ip =str(get("https://api.ipify.org").text)
                print_speak(f"your IP address is : {ip}")
            except Exception as e:
                print_speak("Sorry I cannot able to do this")
        elif ("detail" in query) and ("phone" in query) and ("number" in query):
            try:
                speak("Enter the phone number to find Detail")
                number = input("Enter the phone number to find Detail : ")
                searchphonedetail(number)
            except Exception as e:
                print_speak("Sorry I cannot able to do this")
        elif (("screenshot" in query) and ("take" in query)):
            try:
                speak_print("Screenshot automatically taken under 5 second")
                for x in range(5,0,-1):
                    print(x)
                    speak(x)
                    sleep(1)
                pyautogui.hotkey('win', 'prtscr')
                print_speak("Screenshot has been taken sucessfully")
            except Exception as e:
                print_speak("Sorry I cannot able to do this")
        elif ("sleep" in query):
            print_speak("OK thank you to use me you will call me any time")
            print("######################################################################################################")
            break
        elif ("power left" in query) or ("battery" in query) :
            battery = psutil.sensors_battery()
            percentage = battery.percent
            print_speak(f"Current battery percentage {percentage}%")
            per = percentage
            if per>=70:
                print_speak("We have enough battery to continue our work")
            elif (per>=40) and (per<75):
                print_speak("We should connect our system to charging point to charge battery")
            elif(per>=15)and(per<40):
                print_speak("We don't have enough battery, to continue our work")
            else:
                print_speak("We have very low power , please connect our system to charging")
        elif ((("volume" in query) or ("sound" in query)) and ("up" in query)):
            try:
                for i in range(0,8):
                    pyautogui.press("volumeup")
            except Exception as e:
                print_speak("Sorry I cannot able to do this")
        elif ((("volume" in query) or ("sound" in query)) and ("down" in query)):
            try:
                for i in range(0,8):
                    pyautogui.press("volumedown")
            except Exception as e:
                print_speak("Sorry I cannot able to do this")
        elif (("mute" in query)) :
            try:
                pyautogui.press("volumemute")
            except Exception as e:
                print_speak("Sorry I cannot able to do this")
        elif "how " in query:
                questions = query
                if 1 == 1:
                        print_speak("Searching for result please wait its may take few time...")
                        max_res = 1
                        howto = search_wikihow(questions,max_res)
                        assert len(howto) == 1
                        type = takespeak_or_print()
                        if "speak" in type:
                            howto[0].print()
                            speak(howto[0].summary)
                        else:
                            howto[0].print()  
        elif "search " in query:
            if "search for " in query:
                query = query.replace("search for ","") 
            if "search " in query:                        
                query = query.replace("search","")
            if "jarvis " in query:
                query = query.replace("jarvis","")
            else:
                query = query
            print_speak("Searching...")
            try:
                pywhatkit.search(query)
            except:
                print_speak("Sorry, But I cannot able to do this")
        elif "what " in query :
            if "into " in query:
                query = query.replace("into","*")
            elif "jarvis " in query:
                query = query.replace("jarvis ","")
            try:
                client = wolframalpha.Client("JPP653-GLJUU377UV") 
                question = query 
                res = client.query(question) 
                answer = next(res.results).text 
                print_speak(answer) 
            except:
                print_speak("Sorry, But I cannot have following data")
        elif "weather" in query or "mausam" in query or "vedar" in query:
            try:
                city = citytake()
                weather(city)
            except Exception as e:
                print_speak("sorry  but I cannot able to do this")       
        elif ("tired" in query)or ("tire " in query):
            print_speak("If you feel tired ,I play song for you, So you feel batter")
            musc_dr = "E:\\music"
            int = random.randint(1,14)
            songs = os.listdir(musc_dr)
            os.startfile(os.path.join(musc_dr,songs[int]))  
        elif "news" in query or "new" in query:
            news()
        sleep(1)  
if __name__ == "__main__":
    while True:
        query = wakeup_or_shutdown()
        query = str(query)
        query = query.lower()
        if ("wake up" in query) or ("wakeup" in query):
            print("######################################################################################################")
            executation()
        elif((("shutdown" in query) or ("shut down" in query))\
              or (("switch off" in query) or ("switchoff" in query))\
                or(("goodbye" in query) or ("good bye" in query))):
            print_speak("Shutting down thanks to use me Have a good day")
            print("######################################################################################################")
            quit()
